package osu.cse3241;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/**
 * <h1>CSE3241 Introduction to Database Systems - Sample Java application.</h1>
 *
 * <p>
 * Sample app to be used as guidance and a foundation for students of CSE3241
 * Introduction to Database Systems at The Ohio State University.
 * </p>
 *
 * <h2>!!! - Vulnerable to SQL injection - !!!</h2>
 * <p>
 * Correct the code so that it is not vulnerable to a SQL injection attack.
 * ("Parameter substitution" is the usual way to do this.)
 * </p>
 *
 * <p>
 * Class is written in Java SE 8 and in a procedural style. Implement a
 * constructor if you build this app out in OOP style.
 * </p>
 * <p>
 * Modify and extend this app as necessary for your project.
 * </p>
 *
 * <h2>Language Documentation:</h2>
 * <ul>
 * <li><a href="https://docs.oracle.com/javase/8/docs/">Java SE 8</a></li>
 * <li><a href="https://docs.oracle.com/javase/8/docs/api/">Java SE 8
 * API</a></li>
 * <li><a href=
 * "https://docs.oracle.com/javase/8/docs/technotes/guides/jdbc/">Java JDBC
 * API</a></li>
 * <li><a href="https://www.sqlite.org/docs.html">SQLite</a></li>
 * <li><a href="http://www.sqlitetutorial.net/sqlite-java/">SQLite Java
 * Tutorial</a></li>
 * </ul>
 *
 * <h2>MIT License</h2>
 *
 * <em>Copyright (c) 2019 Leon J. Madrid, Jeff Hachtel</em>
 *
 * <p>
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * </p>
 *
 *
 * @author Leon J. Madrid (madrid.1), Jeff Hachtel (hachtel.5)
 *
 * @modifier Joseph Canova.4
 *
 */

public class CSE3241app {

    /**
     * The database file name.
     *
     * Make sure the database file is in the root folder of the project if you
     * only provide the name and extension.
     *
     * Otherwise, you will need to provide an absolute path from your C: drive
     * or a relative path from the folder this class is in.
     */
    private static String DATABASE = "Project.db";

    /**
     * Query statement which lists the entire Actor table.
     *
     * Remember to include the semicolon at the end of the statement string.
     * (Not all programming languages and/or packages require the semicolon
     * (e.g., Python's SQLite3 library))
     */
    private static String sqlStatementOne = "SELECT * FROM Actor";

    /**
     * Query statement which lists all titles of audiobooks written by B B.
     *
     * Remember to include the semicolon at the end of the statement string.
     * (Not all programming languages and/or packages require the semicolon
     * (e.g., Python's SQLite3 library))
     */
    private static String sqlStatementTwo = "SELECT Title\r\n"
            + "FROM Inventory\r\n" + "WHERE Inventory.Inv_ID IN\r\n"
            + "    (SELECT AUD_ID\r\n"
            + "     FROM Audiobook, Written_By, Author\r\n"
            + "     WHERE Author.Fname = 'B'\r\n"
            + "     AND Author.Lname = 'B'\r\n"
            + "     AND Written_By.Auth_ID = Author.ID\r\n"
            + "     AND Written_By.Audio_ID = Audiobook.AUD_ID);";

    /**
     * Query statement which lists all titles of movies directed by N P.
     *
     * Remember to include the semicolon at the end of the statement string.
     * (Not all programming languages and/or packages require the semicolon
     * (e.g., Python's SQLite3 library))
     */
    private static String sqlStatementThree = "SELECT Title\r\n"
            + "FROM Inventory\r\n" + "WHERE Inventory.Inv_ID IN \r\n"
            + "    (SELECT MOV_ID\r\n"
            + "     FROM Director, Directed_By, Movie\r\n"
            + "     WHERE Director.Fname = 'N'\r\n"
            + "     AND Director.Lname = 'P'\r\n"
            + "     AND Movie.MOV_ID = Directed_By.Movie_ID\r\n"
            + "     AND Directed_By.Direct_ID = Director.ID);";

    /**
     * Query statement which gets all fees accrued by patron D E
     *
     * Remember to include the semicolon at the end of the statement string.
     * (Not all programming languages and/or packages require the semicolon
     * (e.g., Python's SQLite3 library))
     */
    private static String sqlStatementFour = "SELECT SUM(Fee.Amount) AS SUM\r\n"
            + "FROM Patron, Fee\r\n" + "WHERE Patron.Fname = 'D'\r\n"
            + "AND Patron.Lname = 'E'\r\n"
            + "AND Fee.HolderNo = Patron.CardNo;";

    /**
     * Connects to the database if it exists, creates it if it does not, and
     * returns the connection object.
     *
     * @param databaseFileName
     *            the database file name
     * @return a connection object to the designated database
     */
    public static Connection initializeDB(String databaseFileName) {
        /**
         * The "Connection String" or "Connection URL".
         *
         * "jdbc:sqlite:" is the "subprotocol". (If this were a SQL Server
         * database it would be "jdbc:sqlserver:".)
         */
        String url = "jdbc:sqlite:" + databaseFileName;
        System.out.println(url);
        Connection conn = null; // If you create this variable inside the Try block it will be out of scope
        try {
            conn = DriverManager.getConnection(url);
            if (conn != null) {
                // Provides some positive assurance the connection and/or creation was successful.
                DatabaseMetaData meta = conn.getMetaData();
                System.out
                        .println("The driver name is " + meta.getDriverName());
                System.out.println(
                        "The connection to the database was successful.");
            } else {
                // Provides some feedback in case the connection failed but did not throw an exception.
                System.out.println("Null Connection");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            System.out
                    .println("There was a problem connecting to the database.");
        }
        return conn;
    }

    /**
     * prints table to user.
     *
     * @param conn
     *            a connection object
     * @param sql
     *            a SQL statement that returns rows
     */
    public static void sqlQueryReturnTable(Connection conn, String sql) {
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                String value = rsmd.getColumnName(i);
                System.out.print(value);
                if (i < columnCount) {
                    System.out.print(",  ");
                }
            }
            System.out.print("\n");
            while (rs.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    String columnValue = rs.getString(i);
                    System.out.print(columnValue);
                    if (i < columnCount) {
                        System.out.print(",  ");
                    }
                }
                System.out.print("\n");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Connection conn = initializeDB(DATABASE);
        int chooser;
        System.out.println("Enter a number to: ");
        System.out.println("(1) Get a table of Actors in the database");
        System.out.println("(2) See titles of all audiobooks written by B B.");
        System.out.println("(3) See titles of all movies directed by N P");
        System.out.println(
                "(4) Get sum of all fees currently accrued by Patron D E");
        chooser = Integer.parseInt(in.nextLine());
        if (chooser == 1) {
            sqlQueryReturnTable(conn, sqlStatementOne);
        } else if (chooser == 2) {
            sqlQueryReturnTable(conn, sqlStatementTwo);
        } else if (chooser == 3) {
            sqlQueryReturnTable(conn, sqlStatementThree);
        } else {
            sqlQueryReturnTable(conn, sqlStatementFour);
        }
        in.close();
    }
}
